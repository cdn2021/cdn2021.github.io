=================================================================
README

O&O DISKRECOVERY

RELEASE 14.0 BUILD 17

=================================================================

CONTENTS:
---------

1) INSTALLATION NOTES
2) SUPPORT / CONTACT

-----------------------------------------------------------------
1) INSTALLATION NOTES
---------------------

* O&O DiskRecovery works with the following operating systems:

    + Microsoft Windows 7 (all editions, x32/x64)
    + Microsoft Windows 8.1 (all editions, x32/x64)
    + Microsoft Windows 10 (all editions, x32/x64)

    + Microsoft Windows Server 2008 (all editions**, x32/x64)
    + Microsoft Windows Server 2008 R2 (all editions**) 
    + Microsoft Windows Server 2012 (all editions**) 
    + Microsoft Windows Server 2012 R2 (all editions**) 
    + Microsoft Windows Server 2016 (all editions**)
    + Microsoft Windows Server 2019 (all editions**)

 ** Except Core Installations

* You need Microsoft Internet Explorer 6.0 or higher for
  correct functioning of O&O DiskRecovery. In addition, it is
  required for displaying the online help. 

* To uninstall O&O DiskRecovery, you may remove the entry
  "O&O DiskRecovery" using "Add/Remove Software" from the
  control panel.

-----------------------------------------------------------------
2) SUPPORT / CONTACT
--------------------

O&O Software GmbH

Office:     Am Borsigturm 48
            13507 Berlin
            Germany

Phone:      +49 (0)30 991 9162-00
Fax:        +49 (0)30 991 9162-99

Sales:      sales@oo-software.com
Info:       info@oo-software.com
Support:    support@oo-software.com

Internet:   http://www.oo-software.com
-----------------------------------------------------------------



